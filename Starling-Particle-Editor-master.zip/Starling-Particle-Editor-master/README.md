Starling-Particle-Editor
========================

Actionscript 3 Flash tool to create particle effect files (.pex) compatible for use with Starling and Sparrow frameworks.

Online version here: http://onebyonedesign.com/flash/particleeditor/
